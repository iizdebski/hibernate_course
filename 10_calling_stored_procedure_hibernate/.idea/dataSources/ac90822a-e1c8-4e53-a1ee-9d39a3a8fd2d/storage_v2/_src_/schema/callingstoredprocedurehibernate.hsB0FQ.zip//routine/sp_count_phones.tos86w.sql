create
  definer = root@localhost procedure sp_count_phones(IN personId int, OUT phoneCount int)
BEGIN
  SELECT COUNT(*) INTO phoneCount
  FROM Phone p
  WHERE p.person_id = personId;
END;

