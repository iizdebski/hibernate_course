create
  definer = root@localhost function fn_count_phones(personId int) returns int
BEGIN
  DECLARE phoneCount integer;
  SELECT COUNT(*) INTO phoneCount
  FROM Phone p
  WHERE p.person_id = personId;
  RETURN phoneCount;
END;

